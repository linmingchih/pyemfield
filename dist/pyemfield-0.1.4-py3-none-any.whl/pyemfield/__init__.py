# Initialization file for pyffd package
from .ffd import *